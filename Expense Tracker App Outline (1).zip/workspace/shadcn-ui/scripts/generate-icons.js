import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const sizes = [72, 96, 128, 144, 152, 192, 384, 512];
const baseIconPath = path.join(__dirname, "../public/icons/icon-base.svg");

try {
  console.log("Reading base icon from:", baseIconPath);
  const baseIconContent = fs.readFileSync(baseIconPath, "utf8");
  
  // Create SVG icons for each size
  sizes.forEach(size => {
    const iconContent = baseIconContent.replace("<svg", `<svg width="${size}" height="${size}"`);
    const iconPath = path.join(__dirname, `../public/icons/icon-${size}x${size}.svg`);
    fs.writeFileSync(iconPath, iconContent);
    console.log(`Created icon: icon-${size}x${size}.svg`);
  });
  
  console.log("All icons generated successfully!");
} catch (error) {
  console.error("Error generating icons:", error);
}
