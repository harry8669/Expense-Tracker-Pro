import { useState } from 'react';
import { Toaster } from '@/components/ui/sonner';
import { TooltipProvider } from '@/components/ui/tooltip';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { ExpenseProvider } from './context/ExpenseContext';
import { Layout } from './components/Layout';
import { SplashScreen } from './components/SplashScreen';
import Dashboard from './pages/Dashboard';
import Expenses from './pages/Expenses';
import NewExpense from './pages/NewExpense';
import EditExpense from './pages/EditExpense';
import Withdrawals from './pages/Withdrawals';
import NewWithdrawal from './pages/NewWithdrawal';
import EditWithdrawal from './pages/EditWithdrawal';
import Reports from './pages/Reports';
import MonthlySummary from './pages/MonthlySummary';
import Settings from './pages/Settings';
import NotFound from './pages/NotFound';

const queryClient = new QueryClient();

const App = () => {
  const [showSplash, setShowSplash] = useState(true);

  if (showSplash) {
    return <SplashScreen onComplete={() => setShowSplash(false)} />;
  }

  return (
    <QueryClientProvider client={queryClient}>
      <ExpenseProvider>
        <TooltipProvider>
          <Toaster />
          <BrowserRouter>
            <Routes>
              <Route path="/" element={<Layout />}>
                <Route index element={<Dashboard />} />
                <Route path="expenses" element={<Expenses />} />
                <Route path="expenses/new" element={<NewExpense />} />
                <Route path="expenses/edit/:id" element={<EditExpense />} />
                <Route path="withdrawals" element={<Withdrawals />} />
                <Route path="withdrawals/new" element={<NewWithdrawal />} />
                <Route path="withdrawals/edit/:id" element={<EditWithdrawal />} />
                <Route path="reports" element={<Reports />} />
                <Route path="monthly-summary" element={<MonthlySummary />} />
                <Route path="settings" element={<Settings />} />
                <Route path="*" element={<NotFound />} />
              </Route>
            </Routes>
          </BrowserRouter>
        </TooltipProvider>
      </ExpenseProvider>
    </QueryClientProvider>
  );
};

export default App;