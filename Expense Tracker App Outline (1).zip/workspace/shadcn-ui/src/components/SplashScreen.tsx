import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { WalletIcon } from 'lucide-react';

interface SplashScreenProps {
  onComplete: () => void;
}

export function SplashScreen({ onComplete }: SplashScreenProps) {
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(false);
      setTimeout(onComplete, 500); // Wait for exit animation
    }, 2000);

    return () => clearTimeout(timer);
  }, [onComplete]);

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-background"
        >
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="flex flex-col items-center"
          >
            <div className="mb-4 flex h-20 w-20 items-center justify-center rounded-full bg-primary">
              <WalletIcon className="h-10 w-10 text-primary-foreground" />
            </div>
            <motion.h1 
              className="text-3xl font-bold"
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.3, duration: 0.5 }}
            >
              Expense Tracker
            </motion.h1>
            <motion.div 
              className="mt-8 h-1.5 w-48 overflow-hidden rounded-full bg-muted"
              initial={{ width: 0 }}
              animate={{ width: "12rem" }}
              transition={{ delay: 0.5, duration: 1 }}
            >
              <div className="h-full w-full bg-primary"></div>
            </motion.div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}