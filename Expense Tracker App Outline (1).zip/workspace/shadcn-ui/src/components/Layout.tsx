import { ReactNode } from "react";
import { useLocation, Link, Outlet } from "react-router-dom";
import { cn } from "@/lib/utils";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";
import { CalendarIcon, BarChartIcon, WalletIcon, SettingsIcon, HomeIcon, PlusCircleIcon } from "lucide-react";

export function Layout() {
  const location = useLocation();
  
  const isActive = (path: string) => {
    return location.pathname === path;
  };

  const navItems = [
    { icon: HomeIcon, label: "Dashboard", path: "/" },
    { icon: WalletIcon, label: "Expenses", path: "/expenses" },
    { icon: PlusCircleIcon, label: "Withdrawals", path: "/withdrawals" },
    { icon: BarChartIcon, label: "Reports", path: "/reports" },
    { icon: CalendarIcon, label: "Monthly", path: "/monthly-summary" },
    { icon: SettingsIcon, label: "Settings", path: "/settings" },
  ];

  return (
    <div className="flex flex-col h-[100dvh]">
      {/* Main content */}
      <div className="flex-1 overflow-hidden">
        <ScrollArea className="h-full">
          <main className="container max-w-6xl mx-auto pb-24 sm:pb-20 px-4 py-4 md:py-8 md:px-8 md:ml-60">
            <Outlet />
          </main>
        </ScrollArea>
      </div>
      
      {/* Bottom Navigation for Mobile */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 border-t bg-background z-10 shadow-lg">
        <div className="flex justify-between px-1">
          {navItems.slice(0, 5).map((item) => (
            <Link key={item.path} to={item.path} className="w-full">
              <Button
                variant="ghost"
                size="sm"
                className={cn(
                  "w-full flex flex-col h-16 rounded-none px-1",
                  isActive(item.path) ? "bg-accent" : "hover:bg-accent/50"
                )}
              >
                <item.icon className={cn("h-5 w-5", isActive(item.path) ? "text-primary" : "text-muted-foreground")} />
                <span className={cn("text-[10px] mt-1 truncate", isActive(item.path) ? "text-primary font-medium" : "text-muted-foreground")}>
                  {item.label}
                </span>
              </Button>
            </Link>
          ))}
        </div>
      </div>
      
      {/* Sidebar for Desktop */}
      <div className="hidden md:block fixed top-0 left-0 h-full w-60 border-r bg-background z-10 shadow-md">
        <div className="flex flex-col h-full py-6">
          <div className="px-6 mb-6">
            <h1 className="text-xl font-bold tracking-tight">Expense Tracker</h1>
          </div>
          <div className="space-y-1 px-3">
            {navItems.map((item) => (
              <Link key={item.path} to={item.path}>
                <Button
                  variant={isActive(item.path) ? "secondary" : "ghost"}
                  size="sm"
                  className={cn(
                    "w-full justify-start",
                    isActive(item.path) ? "bg-secondary" : "hover:bg-secondary/80"
                  )}
                >
                  <item.icon className="mr-2 h-4 w-4" />
                  {item.label}
                </Button>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}