import { Button } from "@/components/ui/button";
import { Download } from "lucide-react";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import { ExpenseType, WithdrawalType } from "@/types";

interface PdfExportProps {
  type: "monthly" | "yearly";
  year: string;
  month?: string;
  expenses: ExpenseType[];
  withdrawals: WithdrawalType[];
  categories: { id: string; name: string; color: string }[];
  totalExpenses: number;
  totalWithdrawals: number;
}

export function PdfExport({
  type,
  year,
  month,
  expenses,
  withdrawals,
  categories,
  totalExpenses,
  totalWithdrawals,
}: PdfExportProps) {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const getMonthName = (monthNumber: string) => {
    const months = [
      "January", "February", "March", "April", "May", "June",
      "July", "August", "September", "October", "November", "December"
    ];
    return months[parseInt(monthNumber) - 1];
  };

  const exportPdf = () => {
    const doc = new jsPDF();
    const reportTitle = type === "monthly" 
      ? `Expense Report - ${getMonthName(month!)} ${year}`
      : `Yearly Expense Report - ${year}`;
    
    // Add title
    doc.setFontSize(18);
    doc.text(reportTitle, 14, 22);
    doc.setFontSize(11);
    doc.setTextColor(100);
    
    // Add current date
    const currentDate = new Date().toLocaleDateString();
    doc.text(`Generated on: ${currentDate}`, 14, 30);
    
    // Add summary section
    doc.setFontSize(14);
    doc.setTextColor(0);
    doc.text("Summary", 14, 45);
    
    // Summary table
    autoTable(doc, {
      startY: 50,
      head: [["Description", "Amount"]],
      body: [
        ["Total Expenses", formatCurrency(totalExpenses)],
        ["Total Withdrawals", formatCurrency(totalWithdrawals)],
        ["Net Balance", formatCurrency(totalWithdrawals - totalExpenses)]
      ],
      theme: "striped",
      headStyles: { fillColor: [41, 128, 185] },
    });
    
    // Category summary
    const categoryTotals: Record<string, number> = {};
    expenses.forEach((expense) => {
      const categoryId = expense.categoryId;
      if (!categoryTotals[categoryId]) categoryTotals[categoryId] = 0;
      categoryTotals[categoryId] += expense.amount;
    });
    
    const categoryData = Object.entries(categoryTotals).map(([categoryId, total]) => {
      const category = categories.find((c) => c.id === categoryId);
      return [category?.name || "Unknown", formatCurrency(total)];
    });
    
    if (categoryData.length > 0) {
      doc.setFontSize(14);
      doc.text("Expenses by Category", 14, doc.lastAutoTable.finalY + 20);
      
      autoTable(doc, {
        startY: doc.lastAutoTable.finalY + 25,
        head: [["Category", "Amount"]],
        body: categoryData,
        theme: "striped",
        headStyles: { fillColor: [231, 76, 60] },
      });
    }
    
    // Detailed expenses
    if (expenses.length > 0) {
      doc.setFontSize(14);
      doc.text("Expense Details", 14, doc.lastAutoTable.finalY + 20);
      
      const expenseData = expenses.map((expense) => {
        const category = categories.find((c) => c.id === expense.categoryId);
        return [
          new Date(expense.date).toLocaleDateString(),
          expense.description,
          category?.name || "Unknown",
          formatCurrency(expense.amount)
        ];
      });
      
      autoTable(doc, {
        startY: doc.lastAutoTable.finalY + 25,
        head: [["Date", "Description", "Category", "Amount"]],
        body: expenseData,
        theme: "striped",
        headStyles: { fillColor: [52, 152, 219] },
      });
    }
    
    // Withdrawal details
    if (withdrawals.length > 0) {
      doc.setFontSize(14);
      doc.text("Withdrawal Details", 14, doc.lastAutoTable.finalY + 20);
      
      const withdrawalData = withdrawals.map((withdrawal) => {
        return [
          new Date(withdrawal.date).toLocaleDateString(),
          withdrawal.bankName,
          withdrawal.description,
          formatCurrency(withdrawal.amount)
        ];
      });
      
      autoTable(doc, {
        startY: doc.lastAutoTable.finalY + 25,
        head: [["Date", "Bank", "Description", "Amount"]],
        body: withdrawalData,
        theme: "striped",
        headStyles: { fillColor: [46, 204, 113] },
      });
    }
    
    // Save the PDF
    const fileName = type === "monthly"
      ? `expense_report_${year}_${month}.pdf`
      : `expense_report_${year}.pdf`;
      
    doc.save(fileName);
  };

  return (
    <Button
      variant="outline"
      size="sm"
      className="flex items-center gap-2"
      onClick={exportPdf}
    >
      <Download size={14} />
      {type === "monthly" ? "Export Monthly Report" : "Export Yearly Report"}
    </Button>
  );
}