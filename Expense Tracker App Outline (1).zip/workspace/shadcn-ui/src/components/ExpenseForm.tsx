import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { CalendarIcon } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";

import { ExpenseFormData } from "@/types";

interface ExpenseFormProps {
  initialData?: ExpenseFormData;
  onSubmit: (data: {
    date: string;
    receiver: string;
    purpose: string;
    amount: number;
    categoryId: string;
  }) => void;
  categories: Array<{ id: string; name: string; color: string }>;
}

export default function ExpenseForm({ initialData, onSubmit, categories }: ExpenseFormProps) {
  // Form state
  const [date, setDate] = useState<Date>(
    initialData?.date || new Date()
  );
  const [receiver, setReceiver] = useState(initialData?.receiver || "");
  const [purpose, setPurpose] = useState(initialData?.purpose || "");
  const [amount, setAmount] = useState(initialData?.amount || "");
  const [categoryId, setCategoryId] = useState(initialData?.categoryId || categories[0]?.id || "");
  const [errors, setErrors] = useState<Record<string, string>>({});

  // Handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate form
    const newErrors: Record<string, string> = {};
    
    if (!receiver.trim()) {
      newErrors.receiver = "Receiver name is required";
    }
    
    if (!purpose.trim()) {
      newErrors.purpose = "Purpose is required";
    }
    
    if (!amount.trim()) {
      newErrors.amount = "Amount is required";
    } else if (isNaN(parseFloat(amount))) {
      newErrors.amount = "Amount must be a valid number";
    }
    
    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }
    
    const expenseData = {
      date: date.toISOString(),
      receiver,
      purpose,
      amount: parseFloat(amount),
      categoryId
    };
    
    onSubmit(expenseData);
  };

  return (
    <form id="expense-form" onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="date">Date</Label>
        <Popover>
          <PopoverTrigger asChild>
            <Button
              variant="outline"
              className={cn(
                "w-full justify-start text-left font-normal",
                !date && "text-muted-foreground"
              )}
            >
              <CalendarIcon className="mr-2 h-4 w-4" />
              {date ? format(date, "PPP") : "Select a date"}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0">
            <Calendar
              mode="single"
              selected={date}
              onSelect={(date) => date && setDate(date)}
              initialFocus
            />
          </PopoverContent>
        </Popover>
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="receiver">Receiver</Label>
        <Input
          id="receiver"
          value={receiver}
          onChange={(e) => setReceiver(e.target.value)}
          placeholder="Who received the payment"
          className={errors.receiver ? "border-red-500" : ""}
        />
        {errors.receiver && (
          <p className="text-sm text-red-500">{errors.receiver}</p>
        )}
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="purpose">Purpose</Label>
        <Textarea
          id="purpose"
          value={purpose}
          onChange={(e) => setPurpose(e.target.value)}
          placeholder="What the payment was for"
          className={errors.purpose ? "border-red-500" : ""}
        />
        {errors.purpose && (
          <p className="text-sm text-red-500">{errors.purpose}</p>
        )}
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="category">Category</Label>
        <Select
          value={categoryId}
          onValueChange={setCategoryId}
        >
          <SelectTrigger>
            <SelectValue placeholder="Select a category" />
          </SelectTrigger>
          <SelectContent>
            {categories.map((category) => (
              <SelectItem key={category.id} value={category.id}>
                <div className="flex items-center">
                  <span 
                    className="mr-2 h-2 w-2 rounded-full" 
                    style={{ backgroundColor: category.color }}
                  />
                  {category.name}
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="amount">Amount</Label>
        <div className="relative">
          <span className="absolute left-3 top-2.5">₹</span>
          <Input
            id="amount"
            type="number"
            step="0.01"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder="0.00"
            className={cn("pl-7", errors.amount ? "border-red-500" : "")}
          />
        </div>
        {errors.amount && (
          <p className="text-sm text-red-500">{errors.amount}</p>
        )}
      </div>
    </form>
  );
}