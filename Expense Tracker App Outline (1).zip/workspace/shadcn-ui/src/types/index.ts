// Define the expense type
export type Expense = {
  id: string;
  date: string;
  receiver: string;
  purpose: string;
  amount: number;
  categoryId: string;
};

// Define form data for expenses
export type ExpenseFormData = {
  date: Date;
  receiver: string;
  purpose: string;
  amount: string;
  categoryId: string;
};

// Define the withdrawal type
export type Withdrawal = {
  id: string;
  date: string;
  amount: number;
  bankName: string;
  chequeNo: string;
};

// Define form data for withdrawals
export type WithdrawalFormData = {
  date: Date;
  amount: string;
  bankName: string;
  chequeNo: string;
};

// Define the category type
export type Category = {
  id: string;
  name: string;
  color: string;
};

// Define the monthly summary type
export type MonthlySummary = {
  month: string;
  year: number;
  totalExpenses: number;
  totalWithdrawals: number;
  bankWithdrawals: Record<string, number>;
};