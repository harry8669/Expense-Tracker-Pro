import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { Expense, Withdrawal, Category, MonthlySummary } from "@/types";

// Define mock categories for initial data
const defaultCategories: Category[] = [
  { id: "cat1", name: "Food", color: "#FF5722" },
  { id: "cat2", name: "Transportation", color: "#2196F3" },
  { id: "cat3", name: "Utilities", color: "#4CAF50" },
  { id: "cat4", name: "Entertainment", color: "#9C27B0" },
  { id: "cat5", name: "Other", color: "#607D8B" },
];

interface ExpenseContextType {
  expenses: Expense[];
  withdrawals: Withdrawal[];
  categories: Category[];
  monthlySummaries: MonthlySummary[];
  currentBalance: number;
  addExpense: (expense: Omit<Expense, "id">) => void;
  updateExpense: (expense: Expense) => void;
  deleteExpense: (id: string) => void;
  addWithdrawal: (withdrawal: Omit<Withdrawal, "id">) => void;
  updateWithdrawal: (withdrawal: Withdrawal) => void;
  deleteWithdrawal: (id: string) => void;
  addCategory: (category: Omit<Category, "id">) => void;
  updateCategory: (category: Category) => void;
  deleteCategory: (id: string) => void;
  calculateMonthlySummaries: () => void;
}

const ExpenseContext = createContext<ExpenseContextType | undefined>(undefined);

export const useExpenseContext = () => {
  const context = useContext(ExpenseContext);
  if (context === undefined) {
    throw new Error("useExpenseContext must be used within an ExpenseProvider");
  }
  return context;
};

interface ExpenseProviderProps {
  children: ReactNode;
}

export const ExpenseProvider = ({ children }: ExpenseProviderProps) => {
  const [expenses, setExpenses] = useState<Expense[]>(() => {
    const savedExpenses = localStorage.getItem("expenses");
    return savedExpenses ? JSON.parse(savedExpenses) : [];
  });
  
  const [withdrawals, setWithdrawals] = useState<Withdrawal[]>(() => {
    const savedWithdrawals = localStorage.getItem("withdrawals");
    return savedWithdrawals ? JSON.parse(savedWithdrawals) : [];
  });
  
  const [categories, setCategories] = useState<Category[]>(() => {
    const savedCategories = localStorage.getItem("categories");
    return savedCategories ? JSON.parse(savedCategories) : defaultCategories;
  });
  
  const [monthlySummaries, setMonthlySummaries] = useState<MonthlySummary[]>([]);
  
  const [currentBalance, setCurrentBalance] = useState<number>(() => {
    const savedBalance = localStorage.getItem("currentBalance");
    return savedBalance ? parseFloat(savedBalance) : 0;
  });

  // Save to localStorage whenever state changes
  useEffect(() => {
    localStorage.setItem("expenses", JSON.stringify(expenses));
  }, [expenses]);

  useEffect(() => {
    localStorage.setItem("withdrawals", JSON.stringify(withdrawals));
  }, [withdrawals]);

  useEffect(() => {
    localStorage.setItem("categories", JSON.stringify(categories));
  }, [categories]);

  useEffect(() => {
    localStorage.setItem("currentBalance", currentBalance.toString());
  }, [currentBalance]);

  // Calculate balance
  useEffect(() => {
    const totalWithdrawals = withdrawals.reduce((sum, item) => sum + item.amount, 0);
    const totalExpenses = expenses.reduce((sum, item) => sum + item.amount, 0);
    setCurrentBalance(totalWithdrawals - totalExpenses);
  }, [expenses, withdrawals]);

  // Add an expense
  const addExpense = (expenseData: Omit<Expense, "id">) => {
    const newExpense = { ...expenseData, id: crypto.randomUUID() };
    setExpenses((prev) => [...prev, newExpense]);
    calculateMonthlySummaries();
  };

  // Update an expense
  const updateExpense = (expense: Expense) => {
    setExpenses((prev) => prev.map((item) => (item.id === expense.id ? expense : item)));
    calculateMonthlySummaries();
  };

  // Delete an expense
  const deleteExpense = (id: string) => {
    setExpenses((prev) => prev.filter((item) => item.id !== id));
    calculateMonthlySummaries();
  };

  // Add a withdrawal
  const addWithdrawal = (withdrawalData: Omit<Withdrawal, "id">) => {
    const newWithdrawal = { ...withdrawalData, id: crypto.randomUUID() };
    setWithdrawals((prev) => [...prev, newWithdrawal]);
    calculateMonthlySummaries();
  };

  // Update a withdrawal
  const updateWithdrawal = (withdrawal: Withdrawal) => {
    setWithdrawals((prev) => prev.map((item) => (item.id === withdrawal.id ? withdrawal : item)));
    calculateMonthlySummaries();
  };

  // Delete a withdrawal
  const deleteWithdrawal = (id: string) => {
    setWithdrawals((prev) => prev.filter((item) => item.id !== id));
    calculateMonthlySummaries();
  };

  // Add a category
  const addCategory = (categoryData: Omit<Category, "id">) => {
    const newCategory = { ...categoryData, id: crypto.randomUUID() };
    setCategories((prev) => [...prev, newCategory]);
  };

  // Update a category
  const updateCategory = (category: Category) => {
    setCategories((prev) => prev.map((item) => (item.id === category.id ? category : item)));
  };

  // Delete a category
  const deleteCategory = (id: string) => {
    setCategories((prev) => prev.filter((item) => item.id !== id));
  };

  // Calculate monthly summaries
  const calculateMonthlySummaries = () => {
    const summaries: Record<string, MonthlySummary> = {};

    // Process expenses
    expenses.forEach((expense) => {
      const date = new Date(expense.date);
      const monthYear = `${date.getMonth() + 1}-${date.getFullYear()}`;
      
      if (!summaries[monthYear]) {
        summaries[monthYear] = {
          month: (date.getMonth() + 1).toString(),
          year: date.getFullYear(),
          totalExpenses: 0,
          totalWithdrawals: 0,
          bankWithdrawals: {}
        };
      }
      
      summaries[monthYear].totalExpenses += expense.amount;
    });

    // Process withdrawals
    withdrawals.forEach((withdrawal) => {
      const date = new Date(withdrawal.date);
      const monthYear = `${date.getMonth() + 1}-${date.getFullYear()}`;
      
      if (!summaries[monthYear]) {
        summaries[monthYear] = {
          month: (date.getMonth() + 1).toString(),
          year: date.getFullYear(),
          totalExpenses: 0,
          totalWithdrawals: 0,
          bankWithdrawals: {}
        };
      }
      
      summaries[monthYear].totalWithdrawals += withdrawal.amount;
      
      // Track by bank
      if (!summaries[monthYear].bankWithdrawals[withdrawal.bankName]) {
        summaries[monthYear].bankWithdrawals[withdrawal.bankName] = 0;
      }
      summaries[monthYear].bankWithdrawals[withdrawal.bankName] += withdrawal.amount;
    });

    setMonthlySummaries(Object.values(summaries));
  };

  // Calculate monthly summaries on initial load
  useEffect(() => {
    calculateMonthlySummaries();
  }, []);

  const value: ExpenseContextType = {
    expenses,
    withdrawals,
    categories,
    monthlySummaries,
    currentBalance,
    addExpense,
    updateExpense,
    deleteExpense,
    addWithdrawal,
    updateWithdrawal,
    deleteWithdrawal,
    addCategory,
    updateCategory,
    deleteCategory,
    calculateMonthlySummaries
  };

  return <ExpenseContext.Provider value={value}>{children}</ExpenseContext.Provider>;
};