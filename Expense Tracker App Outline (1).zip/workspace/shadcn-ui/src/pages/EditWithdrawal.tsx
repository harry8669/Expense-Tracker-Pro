import { useNavigate, useParams } from "react-router-dom";
import { useExpenseContext } from "@/context/ExpenseContext";
import { WithdrawalFormData } from "@/types";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { ArrowLeftIcon } from "lucide-react";
import WithdrawalForm from "@/components/WithdrawalForm";
import { useEffect, useState } from "react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export default function EditWithdrawal() {
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  const { withdrawals, updateWithdrawal, deleteWithdrawal } = useExpenseContext();
  
  const [notFound, setNotFound] = useState(false);
  const [initialData, setInitialData] = useState<WithdrawalFormData | null>(null);
  
  useEffect(() => {
    if (id) {
      const withdrawal = withdrawals.find(w => w.id === id);
      if (withdrawal) {
        setInitialData({
          date: new Date(withdrawal.date),
          bankName: withdrawal.bankName,
          chequeNo: withdrawal.chequeNo,
          amount: withdrawal.amount.toString()
        });
      } else {
        setNotFound(true);
      }
    }
  }, [id, withdrawals]);
  
  const handleSave = (data: WithdrawalFormData) => {
    if (id) {
      updateWithdrawal({
        id,
        date: data.date.toISOString(),
        bankName: data.bankName,
        chequeNo: data.chequeNo,
        amount: parseFloat(data.amount)
      });
      navigate("/withdrawals");
    }
  };
  
  const handleDelete = () => {
    if (id) {
      deleteWithdrawal(id);
      navigate("/withdrawals");
    }
  };
  
  if (notFound) {
    return (
      <div className="flex flex-col items-center justify-center h-full">
        <h2 className="text-xl font-bold mb-4">Withdrawal Not Found</h2>
        <p className="mb-4">The withdrawal you're looking for doesn't exist or has been deleted.</p>
        <Button onClick={() => navigate("/withdrawals")}>
          Back to Withdrawals
        </Button>
      </div>
    );
  }
  
  if (!initialData) {
    return (
      <div className="flex justify-center items-center h-full">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }
  
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center">
          <Button 
            variant="ghost" 
            className="mr-4" 
            onClick={() => navigate("/withdrawals")}
          >
            <ArrowLeftIcon className="h-4 w-4 mr-2" />
            Back
          </Button>
          <h1 className="text-2xl font-bold">Edit Withdrawal</h1>
        </div>
        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button variant="destructive">Delete</Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Are you sure?</AlertDialogTitle>
              <AlertDialogDescription>
                This action cannot be undone. This will permanently delete this
                withdrawal entry from your records.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={handleDelete}>Delete</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Edit Withdrawal</CardTitle>
          <CardDescription>Update bank withdrawal details</CardDescription>
        </CardHeader>
        <CardContent>
          <WithdrawalForm 
            initialData={initialData}
            onSubmit={handleSave}
          />
          <div className="flex justify-end mt-4">
            <Button form="withdrawal-form" type="submit">
              Update Withdrawal
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}