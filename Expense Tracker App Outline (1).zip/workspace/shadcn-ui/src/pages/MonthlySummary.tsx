import { useState } from "react";
import { useExpenseContext } from "@/context/ExpenseContext";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export default function MonthlySummary() {
  const { monthlySummaries } = useExpenseContext();
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear().toString());

  // Get unique years from summaries
  const years = Array.from(
    new Set(monthlySummaries.map((summary) => summary.year))
  ).sort((a, b) => b - a);

  // Filter summaries for selected year
  const yearSummaries = monthlySummaries
    .filter((summary) => summary.year === parseInt(selectedYear))
    .sort((a, b) => parseInt(a.month) - parseInt(b.month));

  // Calculate year totals
  const yearTotal = {
    expenses: yearSummaries.reduce((sum, summary) => sum + summary.totalExpenses, 0),
    withdrawals: yearSummaries.reduce((sum, summary) => sum + summary.totalWithdrawals, 0),
  };

  // Get all bank names across all summaries
  const allBanks = new Set<string>();
  yearSummaries.forEach((summary) => {
    Object.keys(summary.bankWithdrawals).forEach((bank) => {
      allBanks.add(bank);
    });
  });
  const bankNames = Array.from(allBanks);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
    }).format(amount);
  };

  const getMonthName = (month: string) => {
    const monthNames = [
      "January", "February", "March", "April", "May", "June",
      "July", "August", "September", "October", "November", "December"
    ];
    return monthNames[parseInt(month) - 1];
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <h1 className="text-2xl font-bold">Monthly Summary</h1>
        <Select
          value={selectedYear}
          onValueChange={(value) => setSelectedYear(value)}
        >
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Select Year" />
          </SelectTrigger>
          <SelectContent>
            {years.length > 0 ? (
              years.map((year) => (
                <SelectItem key={year} value={year.toString()}>
                  {year}
                </SelectItem>
              ))
            ) : (
              <SelectItem value={new Date().getFullYear().toString()}>
                {new Date().getFullYear()}
              </SelectItem>
            )}
          </SelectContent>
        </Select>
      </div>

      {/* Year summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Total Expenses</CardTitle>
            <CardDescription>{selectedYear}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-500">
              {formatCurrency(yearTotal.expenses)}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Total Withdrawals</CardTitle>
            <CardDescription>{selectedYear}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-500">
              {formatCurrency(yearTotal.withdrawals)}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Net Balance</CardTitle>
            <CardDescription>{selectedYear}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {formatCurrency(yearTotal.withdrawals - yearTotal.expenses)}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Monthly breakdown table */}
      <Card>
        <CardHeader>
          <CardTitle>Monthly Breakdown</CardTitle>
          <CardDescription>
            Expenses and withdrawals by month for {selectedYear}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Month</TableHead>
                <TableHead>Expenses</TableHead>
                <TableHead>Withdrawals</TableHead>
                <TableHead>Balance</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {yearSummaries.length > 0 ? (
                yearSummaries.map((summary) => (
                  <TableRow key={summary.month}>
                    <TableCell className="font-medium">
                      {getMonthName(summary.month)}
                    </TableCell>
                    <TableCell className="text-red-500">
                      {formatCurrency(summary.totalExpenses)}
                    </TableCell>
                    <TableCell className="text-green-500">
                      {formatCurrency(summary.totalWithdrawals)}
                    </TableCell>
                    <TableCell>
                      {formatCurrency(summary.totalWithdrawals - summary.totalExpenses)}
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={4} className="h-24 text-center">
                    No data available for {selectedYear}
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Bank withdrawals table */}
      {bankNames.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Bank Withdrawals</CardTitle>
            <CardDescription>
              Withdrawals by bank for {selectedYear}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Bank</TableHead>
                  {yearSummaries.map((summary) => (
                    <TableHead key={summary.month}>
                      {getMonthName(summary.month).substring(0, 3)}
                    </TableHead>
                  ))}
                  <TableHead>Total</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {bankNames.map((bank) => {
                  // Calculate total for this bank
                  const bankTotal = yearSummaries.reduce(
                    (sum, summary) => sum + (summary.bankWithdrawals[bank] || 0),
                    0
                  );
                  
                  return (
                    <TableRow key={bank}>
                      <TableCell className="font-medium">{bank}</TableCell>
                      {yearSummaries.map((summary) => (
                        <TableCell key={`${bank}-${summary.month}`}>
                          {summary.bankWithdrawals[bank]
                            ? formatCurrency(summary.bankWithdrawals[bank])
                            : "-"}
                        </TableCell>
                      ))}
                      <TableCell className="font-bold">
                        {formatCurrency(bankTotal)}
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}
    </div>
  );
}