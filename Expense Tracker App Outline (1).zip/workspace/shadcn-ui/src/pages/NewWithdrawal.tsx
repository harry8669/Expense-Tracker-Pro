import { useNavigate } from "react-router-dom";
import { useExpenseContext } from "@/context/ExpenseContext";
import { WithdrawalFormData } from "@/types";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { ArrowLeftIcon } from "lucide-react";

import WithdrawalForm from "@/components/WithdrawalForm";

export default function NewWithdrawal() {
  const navigate = useNavigate();
  const { addWithdrawal } = useExpenseContext();
  
  const handleSave = (data: WithdrawalFormData) => {
    addWithdrawal({
      date: data.date.toISOString(),
      bankName: data.bankName,
      chequeNo: data.chequeNo,
      amount: parseFloat(data.amount)
    });
    navigate("/withdrawals");
  };
  
  return (
    <div className="space-y-6">
      <div className="flex items-center">
        <Button 
          variant="ghost" 
          className="mr-4" 
          onClick={() => navigate("/withdrawals")}
        >
          <ArrowLeftIcon className="h-4 w-4 mr-2" />
          Back
        </Button>
        <h1 className="text-2xl font-bold">Add New Withdrawal</h1>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>New Withdrawal</CardTitle>
          <CardDescription>Enter bank withdrawal details</CardDescription>
        </CardHeader>
        <CardContent>
          <WithdrawalForm onSubmit={handleSave} />
        </CardContent>
      </Card>
    </div>
  );
}