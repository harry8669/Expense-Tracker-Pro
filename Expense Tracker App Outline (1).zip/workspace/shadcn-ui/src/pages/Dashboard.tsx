import { useExpenseContext } from "@/context/ExpenseContext";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { PlusIcon, TrendingDownIcon, TrendingUpIcon, WalletIcon, ArrowRightIcon } from "lucide-react";
import { Link } from "react-router-dom";
import { format } from "date-fns";

export default function Dashboard() {
  const { expenses, withdrawals, currentBalance, monthlySummaries } = useExpenseContext();
  
  // Get current month and year
  const currentDate = new Date();
  const currentMonth = currentDate.getMonth() + 1;
  const currentYear = currentDate.getFullYear();
  
  // Find current month's summary
  const currentMonthSummary = monthlySummaries.find(
    summary => parseInt(summary.month) === currentMonth && summary.year === currentYear
  );
  
  // Get recent expenses and withdrawals (last 5)
  const recentExpenses = [...expenses]
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .slice(0, 5);
    
  const recentWithdrawals = [...withdrawals]
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .slice(0, 5);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
    }).format(amount);
  };

  return (
    <div className="space-y-6 mx-[-50px] my-[90px] px-[70px] py-[50px] bg-[#00000000] mt-[0px] mr-[0px] mb-[0px] ml-[0px] pt-[50px] pr-[240px] pb-[50px] pl-[10px] text-[16px] font-normal font-sans opacity-100 text-[#020817]">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Dashboard</h1>
        <div className="flex gap-2">
          <Link to="/expenses/new">
            <Button size="sm">
              <PlusIcon className="mr-1 h-4 w-4" />
              New Expense
            </Button>
          </Link>
          <Link to="/withdrawals/new">
            <Button size="sm" variant="outline">
              <WalletIcon className="mr-1 h-4 w-4" />
              New Withdrawal
            </Button>
          </Link>
        </div>
      </div>
      
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Current Balance</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center bg-[#00000000] mt-[0px] mr-[0px] mb-[0px] ml-[0px] pt-[0px] pr-[0px] pb-[0px] pl-[0px] text-[16px] font-normal font-sans opacity-100 text-[#020817]">
              <WalletIcon className="h-4 w-4 mr-2 text-primary" />
              <div className="text-2xl font-bold">{formatCurrency(currentBalance)}</div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Monthly Expenses</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <TrendingDownIcon className="h-4 w-4 mr-2 text-red-500" />
              <div className="text-2xl font-bold">
                {formatCurrency(currentMonthSummary?.totalExpenses || 0)}
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Monthly Withdrawals</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <TrendingUpIcon className="h-4 w-4 mr-2 text-green-500" />
              <div className="text-2xl font-bold">
                {formatCurrency(currentMonthSummary?.totalWithdrawals || 0)}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Recent Activities */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Recent Expenses */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Recent Expenses</CardTitle>
              <Link to="/expenses">
                <Button variant="ghost" size="sm" className="gap-1">
                  View All <ArrowRightIcon className="h-4 w-4" />
                </Button>
              </Link>
            </div>
            <CardDescription>Your latest expenses</CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            {recentExpenses.length > 0 ? (
              <div className="divide-y">
                {recentExpenses.map((expense) => (
                  <div key={expense.id} className="flex items-center justify-between p-4">
                    <div>
                      <p className="font-medium">{expense.receiver}</p>
                      <p className="text-sm text-muted-foreground">{expense.purpose}</p>
                      <p className="text-xs text-muted-foreground">
                        {format(new Date(expense.date), "MMM d, yyyy")}
                      </p>
                    </div>
                    <p className="font-medium text-red-500">{formatCurrency(expense.amount)}</p>
                  </div>
                ))}
              </div>
            ) : (
              <p className="p-4 text-center text-muted-foreground">No recent expenses</p>
            )}
          </CardContent>
        </Card>

        {/* Recent Withdrawals */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Recent Withdrawals</CardTitle>
              <Link to="/withdrawals">
                <Button variant="ghost" size="sm" className="gap-1">
                  View All <ArrowRightIcon className="h-4 w-4" />
                </Button>
              </Link>
            </div>
            <CardDescription>Your latest bank withdrawals</CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            {recentWithdrawals.length > 0 ? (
              <div className="divide-y">
                {recentWithdrawals.map((withdrawal) => (
                  <div key={withdrawal.id} className="flex items-center justify-between p-4">
                    <div>
                      <p className="font-medium">{withdrawal.bankName}</p>
                      <p className="text-sm text-muted-foreground">Cheque #{withdrawal.chequeNo}</p>
                      <p className="text-xs text-muted-foreground">
                        {format(new Date(withdrawal.date), "MMM d, yyyy")}
                      </p>
                    </div>
                    <p className="font-medium text-green-500">{formatCurrency(withdrawal.amount)}</p>
                  </div>
                ))}
              </div>
            ) : (
              <p className="p-4 text-center text-muted-foreground">No recent withdrawals</p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

