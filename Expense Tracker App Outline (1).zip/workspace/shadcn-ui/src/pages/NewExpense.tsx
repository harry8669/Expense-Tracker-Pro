import { useNavigate } from "react-router-dom";
import { useExpenseContext } from "@/context/ExpenseContext";
import { ExpenseFormData } from "@/types";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { ArrowLeftIcon } from "lucide-react";

import ExpenseForm from "@/components/ExpenseForm";

export default function NewExpense() {
  const navigate = useNavigate();
  const { categories, addExpense } = useExpenseContext();
  
  const handleSave = (data: ExpenseFormData) => {
    addExpense({
      date: data.date.toISOString(),
      receiver: data.receiver,
      purpose: data.purpose,
      amount: parseFloat(data.amount),
      categoryId: data.categoryId
    });
    navigate("/expenses");
  };
  
  return (
    <div className="space-y-6">
      <div className="flex items-center">
        <Button 
          variant="ghost" 
          className="mr-4" 
          onClick={() => navigate("/expenses")}
        >
          <ArrowLeftIcon className="h-4 w-4 mr-2" />
          Back
        </Button>
        <h1 className="text-2xl font-bold">Add New Expense</h1>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>New Expense</CardTitle>
          <CardDescription>Enter expense details</CardDescription>
        </CardHeader>
        <CardContent>
          <ExpenseForm 
            categories={categories} 
            onSubmit={handleSave} 
          />
          <div className="flex justify-end mt-4">
            <Button form="expense-form" type="submit">
              Add Expense
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}