import { useState } from "react";
import { useExpenseContext } from "@/context/ExpenseContext";
import { format } from "date-fns";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Bar,
  BarChart,
  Cell,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { PdfExport } from "@/components/PdfExport";

export default function Reports() {
  const { expenses, withdrawals, monthlySummaries, categories } = useExpenseContext();
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear().toString());
  const [selectedMonth, setSelectedMonth] = useState((new Date().getMonth() + 1).toString());

  // Get unique years from expenses and withdrawals
  const years = Array.from(
    new Set([
      ...expenses.map((e) => new Date(e.date).getFullYear()),
      ...withdrawals.map((w) => new Date(w.date).getFullYear()),
    ])
  ).sort((a, b) => b - a);

  const months = [
    { value: "1", label: "January" },
    { value: "2", label: "February" },
    { value: "3", label: "March" },
    { value: "4", label: "April" },
    { value: "5", label: "May" },
    { value: "6", label: "June" },
    { value: "7", label: "July" },
    { value: "8", label: "August" },
    { value: "9", label: "September" },
    { value: "10", label: "October" },
    { value: "11", label: "November" },
    { value: "12", label: "December" },
  ];

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      maximumFractionDigits: 0,
    }).format(amount);
  };

  // Prepare monthly data for the selected year
  const monthlyData = months.map((month) => {
    const summary = monthlySummaries.find(
      (s) => s.month === month.value && s.year === parseInt(selectedYear)
    );

    return {
      name: month.label,
      expenses: summary?.totalExpenses || 0,
      withdrawals: summary?.totalWithdrawals || 0,
    };
  });

  // Prepare category data for selected month and year
  const categoryData = categories.map((category) => {
    const categoryExpenses = expenses.filter(
      (e) =>
        e.categoryId === category.id &&
        new Date(e.date).getFullYear() === parseInt(selectedYear) &&
        new Date(e.date).getMonth() + 1 === parseInt(selectedMonth)
    );

    const total = categoryExpenses.reduce((sum, e) => sum + e.amount, 0);

    return {
      name: category.name,
      value: total,
      color: category.color,
    };
  }).filter(item => item.value > 0);

  // Filter expenses and withdrawals for the selected month and year
  const filteredExpenses = expenses.filter(
    (e) =>
      new Date(e.date).getFullYear() === parseInt(selectedYear) &&
      new Date(e.date).getMonth() + 1 === parseInt(selectedMonth)
  );

  const filteredWithdrawals = withdrawals.filter(
    (w) =>
      new Date(w.date).getFullYear() === parseInt(selectedYear) &&
      new Date(w.date).getMonth() + 1 === parseInt(selectedMonth)
  );

  // Calculate bank withdrawal totals
  const bankTotals: Record<string, number> = {};
  filteredWithdrawals.forEach((withdrawal) => {
    if (!bankTotals[withdrawal.bankName]) {
      bankTotals[withdrawal.bankName] = 0;
    }
    bankTotals[withdrawal.bankName] += withdrawal.amount;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <h1 className="text-2xl font-bold">Reports & Analytics</h1>
        <div className="flex flex-col md:flex-row gap-4 items-center">
          <PdfExport 
            type="monthly"
            year={selectedYear}
            month={selectedMonth}
            expenses={filteredExpenses}
            withdrawals={filteredWithdrawals}
            categories={categories}
            totalExpenses={filteredExpenses.reduce((total, expense) => total + expense.amount, 0)}
            totalWithdrawals={filteredWithdrawals.reduce((total, withdrawal) => total + withdrawal.amount, 0)}
          />
          <PdfExport 
            type="yearly"
            year={selectedYear}
            expenses={expenses.filter(e => new Date(e.date).getFullYear() === parseInt(selectedYear))}
            withdrawals={withdrawals.filter(w => new Date(w.date).getFullYear() === parseInt(selectedYear))}
            categories={categories}
            totalExpenses={expenses
              .filter(e => new Date(e.date).getFullYear() === parseInt(selectedYear))
              .reduce((total, expense) => total + expense.amount, 0)}
            totalWithdrawals={withdrawals
              .filter(w => new Date(w.date).getFullYear() === parseInt(selectedYear))
              .reduce((total, withdrawal) => total + withdrawal.amount, 0)}
          />
          <Select
            value={selectedYear}
            onValueChange={(value) => setSelectedYear(value)}
          >
            <SelectTrigger className="w-full sm:w-[180px]">
              <SelectValue placeholder="Select Year" />
            </SelectTrigger>
            <SelectContent>
              {years.length > 0 ? (
                years.map((year) => (
                  <SelectItem key={year} value={year.toString()}>
                    {year}
                  </SelectItem>
                ))
              ) : (
                <SelectItem value={new Date().getFullYear().toString()}>
                  {new Date().getFullYear()}
                </SelectItem>
              )}
            </SelectContent>
          </Select>

          <Select
            value={selectedMonth}
            onValueChange={(value) => setSelectedMonth(value)}
          >
            <SelectTrigger className="w-full sm:w-[180px]">
              <SelectValue placeholder="Select Month" />
            </SelectTrigger>
            <SelectContent>
              {months.map((month) => (
                <SelectItem key={month.value} value={month.value}>
                  {month.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <Tabs defaultValue="monthly" className="space-y-6">
        <TabsList>
          <TabsTrigger value="monthly">Monthly Overview</TabsTrigger>
          <TabsTrigger value="category">Category Analysis</TabsTrigger>
          <TabsTrigger value="comparison">Year Comparison</TabsTrigger>
        </TabsList>

        {/* Monthly Overview Tab */}
        <TabsContent value="monthly">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Monthly Expenses vs Withdrawals</CardTitle>
                <CardDescription>
                  Comparison of expenses and withdrawals for {selectedYear}
                </CardDescription>
              </CardHeader>
              <CardContent className="p-0">
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={monthlyData}>
                      <XAxis dataKey="name" fontSize={12} tickLine={false} axisLine={false} />
                      <YAxis
                        tickFormatter={(value) => `₹${value}`}
                        fontSize={12}
                        tickLine={false}
                        axisLine={false}
                      />
                      <Tooltip 
                        formatter={(value) => formatCurrency(value as number)}
                        labelClassName="font-medium"
                      />
                      <Bar dataKey="expenses" name="Expenses" fill="#ef4444" radius={[4, 4, 0, 0]} />
                      <Bar dataKey="withdrawals" name="Withdrawals" fill="#22c55e" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Monthly Balance Trend</CardTitle>
                <CardDescription>
                  Net balance (withdrawals - expenses) over time for {selectedYear}
                </CardDescription>
              </CardHeader>
              <CardContent className="p-0">
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={monthlyData.map(month => ({
                      ...month,
                      balance: month.withdrawals - month.expenses
                    }))}>
                      <XAxis dataKey="name" fontSize={12} tickLine={false} axisLine={false} />
                      <YAxis
                        tickFormatter={(value) => `₹${value}`}
                        fontSize={12}
                        tickLine={false}
                        axisLine={false}
                      />
                      <Tooltip 
                        formatter={(value) => formatCurrency(value as number)}
                        labelClassName="font-medium"
                      />
                      <Line
                        type="monotone"
                        dataKey="balance"
                        name="Balance"
                        stroke="#3b82f6"
                        strokeWidth={2}
                        activeDot={{ r: 8 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Total Expenses</CardTitle>
                <CardDescription>
                  {months.find(m => m.value === selectedMonth)?.label} {selectedYear}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-red-500">
                  {formatCurrency(filteredExpenses.reduce((total, expense) => total + expense.amount, 0))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Total Withdrawals</CardTitle>
                <CardDescription>
                  {months.find(m => m.value === selectedMonth)?.label} {selectedYear}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-500">
                  {formatCurrency(filteredWithdrawals.reduce((total, withdrawal) => total + withdrawal.amount, 0))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Net Balance</CardTitle>
                <CardDescription>
                  {months.find(m => m.value === selectedMonth)?.label} {selectedYear}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {formatCurrency(
                    filteredWithdrawals.reduce((total, withdrawal) => total + withdrawal.amount, 0) -
                    filteredExpenses.reduce((total, expense) => total + expense.amount, 0)
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Bank Withdrawals Summary */}
          {Object.keys(bankTotals).length > 0 && (
            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Bank Withdrawals Summary</CardTitle>
                <CardDescription>
                  {months.find(m => m.value === selectedMonth)?.label} {selectedYear}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {Object.entries(bankTotals).map(([bank, amount]) => (
                    <div key={bank} className="flex justify-between p-4 border rounded-lg">
                      <div className="font-medium">{bank}</div>
                      <div className="text-green-500 font-medium">{formatCurrency(amount)}</div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Category Analysis Tab */}
        <TabsContent value="category">
          <Card>
            <CardHeader>
              <CardTitle>Expenses by Category</CardTitle>
              <CardDescription>
                {months.find(m => m.value === selectedMonth)?.label} {selectedYear}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {categoryData.length > 0 ? (
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={categoryData}>
                      <XAxis dataKey="name" fontSize={12} tickLine={false} axisLine={false} />
                      <YAxis
                        tickFormatter={(value) => `₹${value}`}
                        fontSize={12}
                        tickLine={false}
                        axisLine={false}
                      />
                      <Tooltip 
                        formatter={(value) => formatCurrency(value as number)}
                        labelClassName="font-medium"
                      />
                      <Bar dataKey="value" name="Amount">
                        {categoryData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  No expense data available for this period
                </div>
              )}
            </CardContent>
          </Card>

          {categoryData.length > 0 && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-6">
              {categoryData.map((category) => (
                <Card key={category.name}>
                  <CardHeader className="pb-2">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-base">
                        <div className="flex items-center">
                          <span
                            className="mr-2 h-3 w-3 rounded-full"
                            style={{ backgroundColor: category.color }}
                          />
                          {category.name}
                        </div>
                      </CardTitle>
                      <span className="text-base font-medium">
                        {formatCurrency(category.value)}
                      </span>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="text-sm text-muted-foreground">
                      {Math.round((category.value / categoryData.reduce((sum, cat) => sum + cat.value, 0)) * 100)}% of total expenses
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {/* Year Comparison Tab */}
        <TabsContent value="comparison">
          {years.length > 1 ? (
            <Card>
              <CardHeader>
                <CardTitle>Yearly Expense Comparison</CardTitle>
                <CardDescription>
                  Compare expenses across different years
                </CardDescription>
              </CardHeader>
              <CardContent className="p-0">
                <div className="h-[400px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={months.map((month) => {
                        const yearData: Record<string, number> = { name: month.label };
                        years.forEach((year) => {
                          const summary = monthlySummaries.find(
                            (s) => s.month === month.value && s.year === year
                          );
                          yearData[`${year}`] = summary?.totalExpenses || 0;
                        });
                        return yearData;
                      })}
                      margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                    >
                      <XAxis dataKey="name" />
                      <YAxis tickFormatter={(value) => `₹${value}`} />
                      <Tooltip formatter={(value) => formatCurrency(value as number)} />
                      {years.map((year, index) => (
                        <Bar
                          key={year}
                          dataKey={`${year}`}
                          name={`${year}`}
                          fill={`hsl(${index * 60}, 70%, 50%)`}
                        />
                      ))}
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          ) : (
            <div className="text-center py-12 text-muted-foreground">
              Need data from multiple years to show comparison
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}