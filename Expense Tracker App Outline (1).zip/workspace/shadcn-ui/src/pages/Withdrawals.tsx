import { useState } from "react";
import { useExpenseContext } from "@/context/ExpenseContext";
import { format } from "date-fns";
import { Link, useNavigate } from "react-router-dom";
import { CalendarIcon, SearchIcon, FilterIcon, PlusIcon, Pencil, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export default function Withdrawals() {
  const navigate = useNavigate();
  const { withdrawals, deleteWithdrawal } = useExpenseContext();
  const [searchQuery, setSearchQuery] = useState("");
  const [bankFilter, setBankFilter] = useState<string | null>(null);
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc");
  
  // Get unique bank names
  const bankNames = Array.from(
    new Set(withdrawals.map((w) => w.bankName))
  );
  
  // Filter and sort withdrawals
  const filteredWithdrawals = withdrawals
    .filter(withdrawal => 
      (bankFilter ? withdrawal.bankName === bankFilter : true) &&
      (searchQuery 
        ? withdrawal.bankName.toLowerCase().includes(searchQuery.toLowerCase()) || 
          withdrawal.chequeNo.toLowerCase().includes(searchQuery.toLowerCase())
        : true
      )
    )
    .sort((a, b) => {
      const dateA = new Date(a.date).getTime();
      const dateB = new Date(b.date).getTime();
      return sortDirection === "asc" ? dateA - dateB : dateB - dateA;
    });
  
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
    }).format(amount);
  };

  const toggleSortDirection = () => {
    setSortDirection(prev => prev === "asc" ? "desc" : "asc");
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Bank Withdrawals</h1>
        <Link to="/withdrawals/new">
          <Button>
            <PlusIcon className="mr-1 h-4 w-4" />
            New Withdrawal
          </Button>
        </Link>
      </div>
      
      {/* Filters and Search */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <SearchIcon className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search withdrawals..."
                className="pl-9"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            
            <div className="flex gap-2">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm" className="h-10">
                    <FilterIcon className="mr-1 h-4 w-4" />
                    Bank
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuLabel>Filter by Bank</DropdownMenuLabel>
                  <DropdownMenuItem onClick={() => setBankFilter(null)}>
                    All Banks
                  </DropdownMenuItem>
                  {bankNames.map((bank) => (
                    <DropdownMenuItem 
                      key={bank}
                      onClick={() => setBankFilter(bank)}
                    >
                      {bank}
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
              
              <Button 
                variant="outline" 
                size="sm" 
                className="h-10"
                onClick={toggleSortDirection}
              >
                <CalendarIcon className="mr-1 h-4 w-4" />
                {sortDirection === "desc" ? "Newest First" : "Oldest First"}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
      
      {/* Withdrawals Table */}
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date</TableHead>
                <TableHead>Bank Name</TableHead>
                <TableHead>Cheque No.</TableHead>
                <TableHead className="text-right">Amount</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredWithdrawals.length > 0 ? (
                filteredWithdrawals.map((withdrawal) => (
                  <TableRow key={withdrawal.id}>
                    <TableCell>
                      {format(new Date(withdrawal.date), "MMM d, yyyy")}
                    </TableCell>
                    <TableCell>{withdrawal.bankName}</TableCell>
                    <TableCell>{withdrawal.chequeNo}</TableCell>
                    <TableCell className="text-right font-medium text-green-600">
                      {formatCurrency(withdrawal.amount)}
                    </TableCell>
                    <TableCell className="w-[100px]">
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => navigate(`/withdrawals/edit/${withdrawal.id}`)}
                        >
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="text-red-500"
                          onClick={() => deleteWithdrawal(withdrawal.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={4} className="h-24 text-center">
                    {searchQuery || bankFilter
                      ? "No withdrawals match your filters"
                      : "No withdrawals recorded yet"}
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}