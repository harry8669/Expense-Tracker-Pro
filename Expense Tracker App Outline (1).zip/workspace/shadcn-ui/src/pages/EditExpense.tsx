import { useNavigate, useParams } from "react-router-dom";
import { useExpenseContext } from "@/context/ExpenseContext";
import { ExpenseFormData } from "@/types";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { ArrowLeftIcon } from "lucide-react";
import ExpenseForm from "@/components/ExpenseForm";
import { useEffect, useState } from "react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export default function EditExpense() {
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  const { expenses, categories, updateExpense, deleteExpense } = useExpenseContext();
  
  const [notFound, setNotFound] = useState(false);
  const [initialData, setInitialData] = useState<ExpenseFormData | null>(null);
  
  useEffect(() => {
    if (id) {
      const expense = expenses.find(e => e.id === id);
      if (expense) {
        setInitialData({
          date: new Date(expense.date),
          receiver: expense.receiver,
          purpose: expense.purpose,
          amount: expense.amount.toString(),
          categoryId: expense.categoryId
        });
      } else {
        setNotFound(true);
      }
    }
  }, [id, expenses]);
  
  const handleSave = (data: ExpenseFormData) => {
    if (id) {
      updateExpense({
        id,
        date: data.date.toISOString(),
        receiver: data.receiver,
        purpose: data.purpose,
        amount: parseFloat(data.amount),
        categoryId: data.categoryId
      });
      navigate("/expenses");
    }
  };
  
  const handleDelete = () => {
    if (id) {
      deleteExpense(id);
      navigate("/expenses");
    }
  };
  
  if (notFound) {
    return (
      <div className="flex flex-col items-center justify-center h-full">
        <h2 className="text-xl font-bold mb-4">Expense Not Found</h2>
        <p className="mb-4">The expense you're looking for doesn't exist or has been deleted.</p>
        <Button onClick={() => navigate("/expenses")}>
          Back to Expenses
        </Button>
      </div>
    );
  }
  
  if (!initialData) {
    return (
      <div className="flex justify-center items-center h-full">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }
  
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center">
          <Button 
            variant="ghost" 
            className="mr-4" 
            onClick={() => navigate("/expenses")}
          >
            <ArrowLeftIcon className="h-4 w-4 mr-2" />
            Back
          </Button>
          <h1 className="text-2xl font-bold">Edit Expense</h1>
        </div>
        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button variant="destructive">Delete</Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Are you sure?</AlertDialogTitle>
              <AlertDialogDescription>
                This action cannot be undone. This will permanently delete this
                expense entry from your records.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={handleDelete}>Delete</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Edit Expense</CardTitle>
          <CardDescription>Update expense details</CardDescription>
        </CardHeader>
        <CardContent>
          <ExpenseForm 
            initialData={initialData}
            categories={categories}
            onSubmit={handleSave}
          />
          <div className="flex justify-end mt-4">
            <Button form="expense-form" type="submit">
              Update Expense
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}